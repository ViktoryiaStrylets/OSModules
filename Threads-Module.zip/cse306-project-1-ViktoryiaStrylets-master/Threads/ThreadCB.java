package osp.Threads;
import osp.Utilities.*;
import osp.IFLModules.*;
import osp.Tasks.*;
import osp.EventEngine.*;
import osp.Hardware.*;
import osp.Devices.*;
import osp.Memory.*;
import osp.Resources.*;
import java.util.*;
import java.time.Duration;
import java.time.Instant;
/**
 * Viktoryia Strylets 111748510
 * I pledge my honor that all parts of this project were done by me individually,
 * without collaboration with anyone,
 * and without consulting any external sources that could help with similar projects.
 */

/**
   This class is responsible for actions related to threads, including
   creating, killing, dispatching, resuming, and suspending threads.

   @OSPProject Threads
 */

public class ThreadCB extends IflThreadCB 
{
	public static PriorityQueue<ThreadCB> ready_queue;
	public long wait_time;
	public long suspend;
	/**
       The thread constructor. Must call 

       	   super();

       as its first statement.

       @OSPProject Threads
	 */
	public ThreadCB()
	{
		// your code goes here
		super();
		this.wait_time=0;
	}
	/**
       This method will be called once at the beginning of the
       simulation. The student can set up static variables here.

       @OSPProject Threads
	 */
	public static void init()
	{
		ready_queue = 
				new PriorityQueue<ThreadCB>(100,new Comparator<ThreadCB>() {
					public int compare(ThreadCB thread1,ThreadCB thread2) {
					if(thread1.getPriority()<thread1.getPriority())
						return 1;
					else if(thread1.getPriority()>thread2.getPriority())
						return -1;
					else return 0; 
					}});
		
	}

	

	/** 
        Sets up a new thread and adds it to the given task. 
        The method must set the ready status 
        and attempt to add thread to task. If the latter fails 
        because there are already too many threads in this task, 
        so does this method, otherwise, the thread is appended 
        to the ready queue and dispatch() is called.

	The priority of the thread can be set using the getPriority/setPriority
	methods. However, OSP itself doesn't care what the actual value of
	the priority is. These methods are just provided in case priority
	scheduling is required.

	@return thread or null

        @OSPProject Threads
	 */
	static public ThreadCB do_create(TaskCB task)
	{
		
		/*set the priority of the task due to the total CPU usage of all its threads*/
	    if(task.getThreadCount()==0)
		task.setPriority(0); 
	    
		/*Don't allow to create a thread when if its too many threads in this task*/
		if(task.getThreadCount()>=IflThreadCB.MaxThreadsPerTask) {
		    dispatch();
			return null;
		}
			

		/*create the new Thread */
		ThreadCB newThread= new ThreadCB();
		
        
         /*associate the newly created thread with provided task
		 * if addThread return FAILURE return null*/

		if(task.addThread(newThread)==IflThreadCB.FAILURE) {
			dispatch();
			return null;
		}
		/* set the threads task*/
		newThread.setTask(task);

		/*set status of created thread*/
		newThread.setStatus(ThreadReady);
		
		
		/*set initial priority to 0 due to waiting time to be 0*/
		newThread.setPriority(0);
		
		
		/*placed the thread on the  queue for ready-to-run threads*/
        ready_queue.add(newThread);
      
		/*dispatch the thread*/
		dispatch();
		return newThread;

	}

	/** 
	Kills the specified thread. 

	The status must be set to ThreadKill, the thread must be
	removed from the task's list of threads and its pending IORBs
	must be purged from all device queues.

	If some thread was on the ready queue, it must removed, if the 
	thread was running, the processor becomes idle, and dispatch() 
	must be called to resume a waiting thread.

	@OSPProject Threads
	 */
	public void do_kill()
	{

		/* get the status of the Thread*/
		int status= this.getStatus();
		IflTaskCB threads_task=this.getTask();
		
		
		/*change status of the thread to ThreadKill*/
		this.setStatus(ThreadKill);

		/*if the status is ready removed the thread from th ready queue*/
		if(status==ThreadReady) {
			ready_queue.remove(this);
		
		}

		/*if status is running*/
		if(status==ThreadRunning) {
			int current_task_priority=this.getTask().getPriority();
			int addTime=(int)(this.getTimeOnCPU()*1000000);
			this.getTask().setPriority((int) (current_task_priority+addTime));

			
			MMU.getPTBR().getTask().setCurrentThread(null);
		    MMU.setPTBR(null);
		}


		/*	purge its pending IORBs from all device queues.*/
		for(int i=0;i<Device.getTableSize();i++) {
			Device device=Device.get(i);
			device.cancelPendingIO(this);
		}
		/*remove the thread from task's list of threads;*/
		threads_task.removeThread(this);

		/*free all the resources */
		ResourceCB.giveupResources(this);


		/*check if the task still have any threads left, if none left -> kill the task*/
		if(threads_task.getThreadCount()==0)
			threads_task.kill();
		
		/*dispatch the thread */
		dispatch();
     return;
	}
	/** Suspends the thread that is currently on the processor on the 
        specified event. 

        Note that the thread being suspended doesn't need to be
        running. It can also be waiting for completion of a page fault
        and be suspended on the IORB that is bringing the page in.

	Thread's status must be changed to ThreadWaiting or higher,
        the processor set to idle, the thread must be in the right
        waiting queue, and dispatch() must be called to give CPU
        control to some other thread.

	@param event - event on which to suspend this thread.

        @OSPProject Threads
	 */
	public void do_suspend(Event event)
	{
		/* Get the status of the thread*/
		int status= this.getStatus();

		/*if the status of the thread is ThreadKill discard request*/
		if(this.getStatus()==ThreadKill) {
			MyOut.print(this, "the status of the thread is Threadkill or threadReady"
					+ ", request disgarded");
			return;}
		
		/*if the thread is in waiting status increment level*/
		if(status>=ThreadWaiting)
			this.setStatus(status+1); 
		/*if the thread is running perform control switch
		 * take to he account the time it took on CPU*/
		if(status==ThreadRunning) {
			int current_task_priority=this.getTask().getPriority();
			int addTime=(int)(this.getTimeOnCPU()*1000000);
			this.getTask().setPriority((int) (current_task_priority+addTime));

			this.setStatus(ThreadWaiting); 
			MMU.setPTBR(null);
			this.getTask().setCurrentThread(null);

          
		}
		
		/*adjust the suspend time*/

		this.suspend=HClock.get();
		
		if(ready_queue.contains(this)) 
		ready_queue.remove(this);
		
		/*place the thread to the waiting queue of this event*/
		if(this.getStatus()>=ThreadWaiting)
			event.addThread(this);
		/*dispatch another thread to be run*/
		dispatch();
	}

	/** Resumes the thread.

	Only a thread with the status ThreadWaiting or higher
	can be resumed.  The status must be set to ThreadReady or
	decremented, respectively.
	A ready thread should be placed on the ready queue.

	@OSPProject Threads
	 */
	public void do_resume()
	{
		/*if the waiting status at level 0 change the status to the ThreadReady*/
		if(this.getStatus()==TaskCB.ThreadWaiting)
			this.setStatus(ThreadReady);

		/*if the status in at the level more than ThreadWaiting decrement the status*/
		else if(this.getStatus()>ThreadWaiting)
			this.setStatus(this.getStatus()-1);
		/*if the status not the thread waiting discard the request*/
		else {
			MyOut.print(this, "the thread "+ this +"not in the waiting status Resume failed");
			dispatch();
			return;
		}
		/*if the thread in ready status put it in the ready queue*/
		if(this.getStatus()==ThreadReady) {
			/*adjust suspend time*/
			this.suspend=HClock.get()-suspend;
			calcPriority(this);
			ready_queue.add(this);
			
		}
		
		
			
		/*give the control of the CPU to the new thread*/
		dispatch(); 
		

	}

	/** 
        Selects a thread from the run queue and dispatches it. 

        If there is just one thread ready to run, reschedule the thread 
        currently on the processor.

        In addition to setting the correct thread status it must
        update the PTBR.

	@return SUCCESS or FAILURE

        @OSPProject Threads
	 */
	public static int do_dispatch()
	{
	
		ThreadCB queue_thread=null;
		TaskCB current_task=null;
		ThreadCB running_thread=null;
		ThreadCB thread_to_run=null;
		
		/*get the current running thread*/
		PageTable current_table=MMU.getPTBR();
		
		if(current_table!=null) {
	    current_task = current_table.getTask();
		running_thread= current_task.getCurrentThread();}
		
		/*recalculate the CPU utilization of the all threads in the task of running thread*/
		if(running_thread!=null) {

			
			int current_task_priority=current_task.getPriority();
			int addTime=(int)(running_thread.getTimeOnCPU()*1000000);
			current_task.setPriority((int)(current_task_priority+addTime));

			/*recalculate the priority of the thread*/
			calcPriority(running_thread);	

		}
		
		/* INVALID CASE
		 * if the queue is empty and no thread is running return failure*/
		if(ready_queue.isEmpty()&&running_thread==null) {
			return FAILURE;}

		
		/*CASE 1 running thread is null and queue is not empty
		 * choose the thread from ready queue */
		
		if(!ready_queue.isEmpty()&&running_thread==null) {
			reHeapify();
			queue_thread=ready_queue.poll();
			thread_to_run=queue_thread;
		}
		
	/*CASE 2 running thread is present ,but queue is empty
		 * reschedule the current running thread
		 */
		else if(running_thread!=null&&ready_queue.isEmpty()) 
		thread_to_run=running_thread;
		
		
	/*CASE 3 running_thread present and the queue is not empty
	 * 
	 */
		else if(running_thread!=null&&!ready_queue.isEmpty()) {
		   /*choose the thread from the queue*/
			reHeapify();
			queue_thread=ready_queue.poll();
			
			
			/*if the priority of the current running thread is less than ready_thread
			 * Preempt the running process and put it back in the ready queue*/
			if(running_thread.getPriority()<queue_thread.getPriority()||
					running_thread.getTimeOnCPU()>=100) {
			/*Preempting the current running thread*/
				
				
				running_thread.setStatus(ThreadReady);
				MMU.setPTBR(null);
				current_task.setCurrentThread(null);
				
				if(running_thread.getTimeOnCPU()<90) {
					running_thread.setPriority(Integer.MAX_VALUE);
				}

				/*add it to the queue*/
				ready_queue.add(running_thread);
				thread_to_run=queue_thread;
			}
		  else { thread_to_run=running_thread;
		        ready_queue.add(queue_thread);
		  }
			
		}
		
		if(thread_to_run!=null) {
	    /*Give the CPU control to the appropriate thread thread*/
		thread_to_run.setStatus(ThreadRunning);
		MMU.setPTBR(thread_to_run.getTask().getPageTable());
		thread_to_run.getTask().setCurrentThread(thread_to_run);}

		/*set timer for the timer interrupt*/
    
	    HTimer.set(100);
       return SUCCESS;

	}

	/**
       Called by OSP after printing an error message. The student can
       insert code here to print various tables and data structures in
       their state just after the error happened.  The body can be
       left empty, if this feature is not used.

       @OSPProject Threads
	 */
	public static void atError()
	{
		getFullStackTrace();
		
	}
	

	/** Called by OSP after printing a warning message. The student
        can insert code here to print various tables and data
        structures in their state just after the warning happened.
        The body can be left empty, if this feature is not used.

        @OSPProject Threads
	 */
	public static void atWarning()
	{
		getPartialStackTrace();

	}

	public static void calcPriority (ThreadCB thread) {
		/*set the time the thread  CPU wait time */
		 thread.wait_time=HClock.get()-thread.getCreationTime()-thread.getTimeOnCPU()-
				 thread.suspend;
		 int convert= (int)(thread.wait_time*1000000);
		/*set priority for thread*/
		int priority=convert/(1+thread.getTask().getPriority());
	    thread.setPriority(priority);
	}
	
	/*the function recalculate priority of the each thread due to either increasing time of 
	 * task priority or waiting time , and reorganize the queue in right priority
	 */
	public static void reHeapify() {
		int size=ready_queue.size();
		while(size!=0) {
		ThreadCB current=ready_queue.remove();
		calcPriority(current);
		ready_queue.add(current);
		size--;
		}
	}
}
